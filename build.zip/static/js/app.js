
// crime statistics for all precincts
let precinctStats = {};
const NUM_BUCKETS = 9;

// object literals do not support non-string keys
const COLORS = {};
COLORS[0] = {r: 255, g: 211, b: 123};
COLORS[1] = {r: 255, g: 186, b: 98};
COLORS[2] = {r: 255, g: 160, b: 72};
COLORS[3] = {r: 255, g: 135, b: 47};
COLORS[4] = {r: 234, g: 109, b: 21};  // default
COLORS[5] = {r: 209, g: 84, b: 0};
COLORS[6] = {r: 183, g: 58, b: 0};
COLORS[7] = {r: 158, g: 33, b: 0};
COLORS[8] = {r: 132, g: 7, b: 0};


function ordinal(i) {
    const j = i % 10;
    const k = i % 100;

    if (j == 1 && k != 11)
        return i + 'st';
    if (j == 2 && k != 12)
        return i + 'nd';
    if (j == 3 && k != 13)
        return i + 'rd';

    return i + 'th';
}


function getMaxPoly(polys) {
    var polyObj = [];
    //now need to find which one is the greater and so label only this
    for (var b = 0; b < polys.length; b++) {
        polyObj.push({ poly: polys[b], area: polys[b].getArea() });
    }
    polyObj.sort(function (a, b) { return a.area - b.area });

    return polyObj[polyObj.length - 1].poly;
};

function getPrecinctBucket(precinct) {
    // Get all totals and the total for this precinct.
    // This total will determine chloropleth bucket/color.
    const totals = [];
    let precinctTotal;
    for (data of precinctStats) {
        totals.push(data.stats.aggregate);

        if (parseInt(data.precinct) === parseInt(precinct))
            precinctTotal = data.stats.aggregate;
    }

    const min = Math.min(...totals);
    const max = Math.max(...totals);
    const bucketSize = (max - min) / NUM_BUCKETS;

    for (let i = 0; i < NUM_BUCKETS; i++) {
        if (precinctTotal <= (min + (i+1)*bucketSize))
            return i;
    }
}

function getPrecinctColor(precinct, alpha=1.0) {
    const {r, g, b} = $.isEmptyObject(precinctStats)
        ? COLORS[4]
        : COLORS[getPrecinctBucket(precinct)];

    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
};


// Text style is consistent throught the map
function getTextStyle(feature) {
    return new ol.style.Style({
        text: new ol.style.Text({
            text: ordinal(feature.get('precinct')),
            font: '12px San Francisco,sans-serif',
            fill: new ol.style.Fill({color: 'white'}),
            stroke: new ol.style.Stroke({color: 'black', width: 3}),
        }),
        geometry(feature) {
            // geom func only displays text in largest polygon for MultiPolygons
            if (feature.getGeometry().getType() === 'MultiPolygon')
                return getMaxPoly(feature.getGeometry().getPolygons()).getInteriorPoint();

            else if (feature.getGeometry().getType() === 'Polygon')
                return feature.getGeometry().getInteriorPoint();
        },
    })
};



const precinctSource = new ol.source.Vector({
    // jsonFeatures provided in template - difficulties with lazy loading via source URL.
    features: (new ol.format.GeoJSON()).readFeatures(jsonFeatures)
});
const precinctExtent = precinctSource.getExtent();


function precinctStyle(feature, resolution) {
    const precinct = feature.get('precinct');

    const polyStyle = new ol.style.Style({
        fill: new ol.style.Fill({
            color: getPrecinctColor(precinct, 0.5),
        }),
        stroke: new ol.style.Stroke({
            color: getPrecinctColor(precinct),
            width: 2,
        }),
    });

    return [polyStyle, getTextStyle(feature)];
};

function highlightStyle(feature, resolution) {
    const precinct = feature.get('precinct');

    const polyStyle = new ol.style.Style({
        fill: new ol.style.Fill({
            color: getPrecinctColor(precinct, 0.9),
        }),
        stroke: new ol.style.Stroke({
            color: getPrecinctColor(precinct),
            width: 4,
        }),
    });

    return [polyStyle, getTextStyle(feature)];
}

function policeLogStyle(feature, resolution) {
    return new ol.style.Style({
        image: new ol.style.Circle({
            radius: Math.min((120 / resolution), 6),
            fill: new ol.style.Fill({color: '#eee'}),
            stroke: new ol.style.Stroke({color: '#222', width: 1}),
        })
    })
};

function kmeansStyle(feature, resolution) {
    return new ol.style.Style({
        image: new ol.style.Circle({
            radius: 6,
            fill: new ol.style.Fill({color: '#CC3333'}),
            stroke: new ol.style.Stroke({color: 'red', width: 2}),
        })
    })
};


const LAYERS = {
    map: new ol.layer.Tile({
        source: new ol.source.Stamen({
            layer: 'toner',
        }),
    }),

    crimeStats: new ol.layer.Vector({
        source: precinctSource,
        style: precinctStyle,
    }),

    policeLog: new ol.layer.Vector({
        style: policeLogStyle,
    }),

    kmeans: new ol.layer.Vector({
        style: kmeansStyle,
    }),
}

const map = new ol.Map({
    target: 'map',
    view: new ol.View({}),

    controls: ol.control.defaults({}).extend([
        new ol.control.ZoomToExtent({extent: precinctExtent}),
        new ol.control.Control({
            element: document.getElementById('overlay'),
        }),
    ]),

    layers: [
        LAYERS.map,
        LAYERS.crimeStats,
        LAYERS.policeLog,
        LAYERS.kmeans,
    ],
});

// hover/highlight
hoverSelect = new ol.interaction.Select({
    condition: ol.events.condition.pointerMove,
    layers: [LAYERS.crimeStats],
    style: highlightStyle,
});
hoverSelect.on('select', (evt) => {
    window.app.highlightedPrecinct = '';

    for (const sel of evt.selected)
        if (sel.getKeys().indexOf('precinct') >= 0)
            window.app.highlightedPrecinct = sel.get('precinct');
});
map.addInteraction(hoverSelect);


map.getView().fit(precinctExtent, {size: map.getSize()});

window.onresize = function resizeMap() {
    const $map = $('#map');
    $map.height(window.innerHeight);
    $map.width(window.innerWidth);

    map.updateSize();
};
$(window).trigger('resize');



const numbaFormatta = new Intl.NumberFormat(useGrouping=true);

const crimesByType = {
    'major felony': [
        'BURGLARY',
        'FELONY ASSAULT',
        'GRAND LARCENY',
        'GRAND LARCENY OF MOTOR VEHICLE',
        'MURDER & NON NEGL. MANSLAUGHTER',
        'RAPE',
        'ROBBERY',
    ],
    'minor felony': [
        'ARSON',
        'FEL. CRIMINAL MISCHIEF & RELATED OFFENSES',
        'FELONY DANGEROUS DRUGS  (1)',
        'FELONY DANGEROUS WEAPONS (2)',
        'FELONY POSSESSION OF STOLEN PROPERTY',
        'FELONY SEX CRIMES (3)',
        'FORGERY/THEFT-FRAUD/IDENTITY THEFT',
        'OTHER FELONIES (4)',
    ],
    'misdemeanor': [
        'ADMINISTRATIVE CODE (6)',
        'AGGRAVATED HARASSMENT 2',
        'ASSAULT 3 AND RELATED OFFENSES',
        'CRIMINAL TRESPASS',
        'FRAUDS (3)',
        'INTOXICATED & IMPAIRED DRIVING',
        'MISD. CRIMINAL MISCHIEF & RELATED OFFENSES',
        'MISDEMEANOR DANGEROUS DRUGS  (1)',
        'MISDEMEANOR DANGEROUS WEAPONS (5)',
        'MISDEMEANOR POSSESSION OF STOLEN PROPERTY',
        'MISDEMEANOR SEX CRIMES (4)',
        'OFFENSES AGAINST PUBLIC ADMINISTRATION (2)',
        'OFFENSES AGAINST THE PERSON (7)',
        'OTHER MISDEMEANORS (8)',
        'PETIT LARCENY',
        'UNAUTHORIZED USE OF A VEHICLE',
        'VEHICLE AND TRAFFIC LAWS',
    ],
    'violation offense': [
        'HARASSMENT 2',
        'OTHER VIOLATIONS (1)',
    ],
};

window.app = new Vue({
    el: '#overlay',
    data: {
        layers: {
            map: true,
            policeLog: false,
            kmeans: false,
        },
        options: {
            kmeansClusters: 10,
        },
        types: {
            'major felony': 'Major felonies',
            'minor felony': 'Minor felonies',
            'misdemeanor': 'Misdemeanors',
            'violation offense': 'Violation offenses',
        },
        selectedType: '',
        selectedCrime: '',
        startYear: '2000',
        endYear: '2016',
        fetching: false,

        highlightedPrecinct: '',
    },

    filters: {
        numba(value) {
            return numbaFormatta.format(value);
        },

        ordinal(value) {
            return ordinal(value);
        },
    },

    watch: {
        selectedType(newValue, oldValue) {
            // clear selectedCrime if the type has changed
            if (newValue !== oldValue)
                this.selectedCrime = '';
        },

        layers: {
            handler(value) {
                LAYERS.map.setVisible(value.map);
                LAYERS.policeLog.setVisible(value.policeLog);
                LAYERS.kmeans.setVisible(value.kmeans);
            },
            deep: true,
        },
    },

    computed: {
        crimes() {
            return crimesByType[this.selectedType];
        },

        highlightedStats() {
            // test highlightedPrecinct first in order to establish Vue dependencies.
            if (!this.highlightedPrecinct)
                return;

            if (!precinctStats || $.isEmptyObject(precinctStats))
                return;

            for (let stats of precinctStats) {
                if (parseInt(stats.precinct) === parseInt(this.highlightedPrecinct))
                    return stats.stats;
            }
        },
    },

    methods: {
        fetch() {
            this.fetching = true;

            const results = [];

            if (this.layers.map) {
                results.push(this.fetchCrimeStats({
                    type: this.selectedType, crime: this.selectedCrime,
                    startYear: this.startYear, endYear: this.endYear,
                }));
            }

            if (this.layers.policeLog) {
                results.push(this.fetchPoliceLog({
                    type: this.selectedType, crime: this.selectedCrime,
                }));
            }

            if (this.layers.kmeans) {
                results.push(this.fetchClusters({
                    type: this.selectedType, crime: this.selectedCrime,
                    num_clusters: this.options.kmeansClusters,
                }));
            }

            Promise.all(results)
            .catch(this.handleError)
            .then(() => {
                this.fetching = false;
            });
        },

        annotateAggregate(stats) {
            let sum = 0;

            for (let key of Object.keys(stats.stats))
                sum += stats.stats[key];

            stats.stats.aggregate = sum;
        },

        fetchCrimeStats(data) {
            return $.getJSON('api/crime-statistics.json', data)
            .then(result => {
                precinctStats = result.data;
                for (stats of precinctStats)
                    this.annotateAggregate(stats);

                // trigger a layer refresh so that the style is redrawn with appropriate color.
                precinctSource.changed();
            })
        },

        fetchPoliceLog(data) {
            const query = $.param(data)

            LAYERS.policeLog.setSource(new ol.source.Vector({
                format: new ol.format.GeoJSON({defaultDataProjection: 'EPSG:3857'}),
                url: `/api/police-log.json?${query}`,
            }));
        },

        fetchClusters(data) {
            const query = $.param(data)

            LAYERS.kmeans.setSource(new ol.source.Vector({
                format: new ol.format.GeoJSON({defaultDataProjection: 'EPSG:3857'}),
                url: `/api/kmeans-clusters.json?${query}`,
            }));
        },

        handleError(reason) {
            alert('There was an error...');
            console.error(reason);
        },
    },
});
