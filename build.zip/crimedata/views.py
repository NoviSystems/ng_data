import json
import time

from django.contrib.gis.db.models import functions, Collect
from django.db.models import Sum
from django.http import JsonResponse, StreamingHttpResponse
from django.utils.http import http_date
from django.views.generic import TemplateView

import sklearn.cluster

from . import models


class Simplify(functions.GeoFunc):
    pass


def precinct_iter(features):
    for feature in features:
        yield '{"type": "Feature", "properties": {"precinct": "%(precinct)d"}, "geometry": %(json)s}' % vars(feature)


def geojson_iterdumps(features):
    # This is the fastest way we've found to build up the geojson for large
    # datasets: let the database do most of the json encoding and then just
    # do string concatenation in python. The Python json encoder is fairly
    # slow in comparison.
    # To use, just pass this generator function's iterator to a
    # StreamingHttpResponse
    yield '{"type": "FeatureCollection", "features": ['

    for i, feature in enumerate(features):
        yield (feature) if i == 0 else (',' + feature)

    yield ']}'


def get_crimes(crimeType=None, crime=None):
    crimes = models.CrimeType.objects.all()

    if crime:
        crimes = crimes.filter(crime=crime)
    elif crimeType:
        crimes = crimes.filter(type=crimeType)

    return crimes


class Home(TemplateView):
    template_name = 'home.html'

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data.update({
            'features': self.precinct_features(),
        })

        return context_data

    def precinct_features(self):
        """
        Returns a GeoJSON string containing NYC's police precinct geometries.

        This code is optimized in the following ways:
        - geometry is simplified using ST_Simplify with a tolerance of .0001,
          reducing the number of points from ~92k to ~11k.
        - each row's geometry is rendered via the geojson DB function.
        - the resulting geojson strings are string concatenated into a fully
          rendered feature collection.
        """
        transform = Simplify('geometry', .0001)
        transform = functions.Transform(transform, 3857)
        transform = functions.AsGeoJSON(transform)

        features = models.PolicePrecinct.objects \
            .annotate(json=transform) \
            .only('precinct') \
            .order_by('precinct')

        features = [
            '{"type": "Feature", "properties": {"precinct": "%(precinct)d"}, "geometry": %(json)s}'
            % vars(feature) for feature in features
        ]

        return '{"type": "FeatureCollection", "features": [%s]}' % ', '.join(features)


def precinct_geometries(request):
    # currently unused, as I'm having difficulties with open layers' lazy source loading.
    transform = Simplify('geometry', .0001)
    transform = functions.Transform(transform, 3857)
    transform = functions.AsGeoJSON(transform)

    features = models.PolicePrecinct.objects \
        .annotate(json=transform) \
        .only('precinct') \
        .order_by('precinct')

    response = StreamingHttpResponse(
        geojson_iterdumps(features),
        content_type='application/json'
    )
    response['Expires'] = http_date(time.time() + 60*15)
    return response


def crime_statistics(request):
    """
    Return the yearly aggregate crime data for the given crime/type over the range of years.

    Data exists from 2000 - 2016.
    """
    data = request.GET
    years = ['year_%d' % i for i in range(int(data['startYear']), int(data['endYear']) + 1)]

    precincts = models.PolicePrecinct.objects.values_list('precinct', flat=True)
    crimes = get_crimes(data.get('type'), data.get('crime'))

    stats = {'data': [{
        'precinct': precinct,
        'stats': models.PrecinctCrime.objects
                       .filter(crime_type__in=crimes)
                       .filter(precinct=precinct)
                       .aggregate(**{year: Sum(year) for year in years})
    } for precinct in precincts]}

    return JsonResponse(stats)


def police_log(request):
    """
    Return the Police Log data for the given crime/type. This is limited to 2016 data.
    """
    transform = Collect('geom')
    transform = functions.Transform(transform, 3857)
    transform = functions.AsGeoJSON(transform)

    data = request.GET
    crimes = get_crimes(data.get('type'), data.get('crime'))

    logs = models.PoliceLog.objects \
        .filter(crime_type__in=crimes) \
        .aggregate(json=transform)['json']

    return StreamingHttpResponse(geojson_iterdumps([logs]), content_type="application/json")


def kmeans_clusters(request):
    """
    Return kmeans clusters for the 2016 Police Log data given the crime/type.
    """
    data = request.GET

    crimes = get_crimes(data.get('type'), data.get('crime'))
    logs = models.PoliceLog.objects \
        .filter(crime_type__in=crimes) \
        .annotate(transformed_pt=functions.Transform('geom', 3857)) \
        .values_list('transformed_pt', flat=True)

    kmeans = sklearn.cluster.KMeans(n_clusters=int(data['num_clusters'])).fit(logs)
    clusters = kmeans.cluster_centers_

    return StreamingHttpResponse(
        geojson_iterdumps(json.dumps({
            "type": "Point",
            "coordinates": list(cluster)
        }) for cluster in clusters),
        content_type="application/json"
    )
