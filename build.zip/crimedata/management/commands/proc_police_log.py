
"""
The mapping of indiviual police logs to a crime type (using the 'log_crime_types' map below) seems to
be roughly accurate. "Good Enough" for kmeans.

Post processing stats
                                                            Aggregate                   Individual reports
Crime Type                                                  (PrecinctCrime.year_2016)   count(Police Log)
----------------------------------------------------------------------------------------------------------
MAJOR FELONY MURDER & NON NEGL. MANSLAUGHTER                335                         338
MAJOR FELONY RAPE                                           1436                        0
MAJOR FELONY ROBBERY                                        15500                       15499
MAJOR FELONY FELONY ASSAULT                                 20346                       20835
MAJOR FELONY BURGLARY                                       12990                       12990
MAJOR FELONY GRAND LARCENY                                  44273                       44261
MAJOR FELONY GRAND LARCENY OF MOTOR VEHICLE                 6327                        6326
MINOR FELONY FORGERY/THEFT-FRAUD/IDENTITY THEFT             11079                       11075
MINOR FELONY ARSON                                          779                         776
MINOR FELONY FELONY SEX CRIMES (3)                          1323                        16
MINOR FELONY FELONY DANGEROUS DRUGS  (1)                    14712                       4747
MINOR FELONY FELONY DANGEROUS WEAPONS (2)                   5464                        5464
MINOR FELONY FELONY POSSESSION OF STOLEN PROPERTY           769                         769
MINOR FELONY FEL. CRIMINAL MISCHIEF & RELATED OFFENSES      9960                        9962
MINOR FELONY OTHER FELONIES (4)                             13900                       13952
MISDEMEANOR MISDEMEANOR POSSESSION OF STOLEN PROPERTY       932                         930
MISDEMEANOR MISDEMEANOR SEX CRIMES (4)                      4922                        139
MISDEMEANOR MISDEMEANOR DANGEROUS DRUGS  (1)                35982                       17902
MISDEMEANOR MISDEMEANOR DANGEROUS WEAPONS (5)               5006                        5007
MISDEMEANOR PETIT LARCENY                                   81262                       83508
MISDEMEANOR ASSAULT 3 AND RELATED OFFENSES                  42419                       52501
MISDEMEANOR INTOXICATED & IMPAIRED DRIVING                  5964                        5965
MISDEMEANOR VEHICLE AND TRAFFIC LAWS                        6580                        6574
MISDEMEANOR MISD. CRIMINAL MISCHIEF & RELATED OFFENSES      38884                       38897
MISDEMEANOR CRIMINAL TRESPASS                               9799                        3928
MISDEMEANOR UNAUTHORIZED USE OF A VEHICLE                   1809                        1810
MISDEMEANOR OFFENSES AGAINST THE PERSON (7)                 1225                        1227
MISDEMEANOR OFFENSES AGAINST PUBLIC ADMINISTRATION (2)      8171                        31755
MISDEMEANOR ADMINISTRATIVE CODE (6)                         942                         940
MISDEMEANOR FRAUDS (3)                                      4639                        4853
MISDEMEANOR AGGRAVATED HARASSMENT 2                         21328                       0
MISDEMEANOR OTHER MISDEMEANORS (8)                          44247                       1194
VIOLATION OFFENSE HARASSMENT 2                              65933                       65928
VIOLATION OFFENSE OTHER VIOLATIONS (1)                      1661                        962
"""

from django.core.management.base import BaseCommand
from django.db import transaction

from crimedata import models


class Command(BaseCommand):
    """
    Translate "Police Log" category/descriptions into a "Crime Type"
    """

    @transaction.atomic
    def handle(self, *args, **options):
        # minor cleaning
        models.PoliceLog.objects \
            .filter(offense='OTHER STATE LAWS (NON PENAL LA') \
            .update(offense='OTHER STATE LAWS (NON PENAL LAW)')
        # minor cleaning
        models.PoliceLog.objects \
            .filter(offense='ADMINISTRATIVE CODES') \
            .update(offense='ADMINISTRATIVE CODE')

        print('uncat pre', models.PoliceLog.objects.filter(crime_type__isnull=True).count())

        for lookup, crime_type in log_crime_types.items():
            category, offense = lookup

            models.PoliceLog.objects \
                .filter(law_category=category) \
                .filter(offense=offense) \
                .update(crime_type=crime_type)

        print('uncat post', models.PoliceLog.objects.filter(crime_type__isnull=True).count())
        models.PoliceLog.objects.filter(crime_type__isnull=True).delete()


# Major Felonies
FELONY_MURDER_AND_NON_NEGL_MANSLAUGHTER = 1
FELONY_RAPE = 2
FELONY_ROBBERY = 3
FELONY_FELONY_ASSAULT = 4
FELONY_BURGLARY = 5
FELONY_GRAND_LARCENY = 6
FELONY_GRAND_LARCENY_OF_MOTOR_VEHICLE = 7

# Minor Felonies
FELONY_FORGERY_FRAUD_IDENTITY_THEFT = 8
FELONY_ARSON = 9
FELONY_SEX_CRIMES = 10
FELONY_DANGEROUS_DRUGS  = 11
FELONY_DANGEROUS_WEAPONS = 12
FELONY_POSSESSION_OF_STOLEN_PROPERTY = 13
FELONY_CRIMINAL_MISCHIEF_AND_RELATED_OFFENSES = 14
FELONY_OTHER_FELONIES = 15

# Misdemeanors
MISDEMEANOR_POSSESSION_OF_STOLEN_PROPERTY = 16
MISDEMEANOR_SEX_CRIMES = 17
MISDEMEANOR_DANGEROUS_DRUGS  = 18
MISDEMEANOR_DANGEROUS_WEAPONS = 19
MISDEMEANOR_PETIT_LARCENY = 20
MISDEMEANOR_ASSAULT_3_AND_RELATED_OFFENSES = 21
MISDEMEANOR_INTOXICATED_AND_IMPAIRED_DRIVING = 22
MISDEMEANOR_VEHICLE_AND_TRAFFIC_LAWS = 23
MISDEMEANOR_CRIMINAL_MISCHIEF_AND_RELATED_OFFENSES = 24
MISDEMEANOR_CRIMINAL_TRESPASS = 25
MISDEMEANOR_UNAUTHORIZED_USE_OF_A_VEHICLE = 26
MISDEMEANOR_OFFENSES_AGAINST_THE_PERSON = 27
MISDEMEANOR_OFFENSES_AGAINST_PUBLIC_ADMINISTRATION = 28
MISDEMEANOR_ADMINISTRATIVE_CODE = 29
MISDEMEANOR_FRAUDS = 30
MISDEMEANOR_AGGRAVATED_HARASSMENT_2 = 31
MISDEMEANOR_OTHER_MISDEMEANORS = 32

# Violation Offenses
VIOLATION_HARASSMENT_2 = 33
VIOLATION_OTHER_VIOLATIONS = 34


log_crime_types = {
    ('FELONY', 'ARSON'):                                        FELONY_ARSON,
    ('FELONY', 'BURGLARY'):                                     FELONY_BURGLARY,
    ('FELONY', 'CHILD ABANDONMENT/NON SUPPORT'):                FELONY_OTHER_FELONIES,
    ('FELONY', 'CRIMINAL MISCHIEF & RELATED OF'):               FELONY_CRIMINAL_MISCHIEF_AND_RELATED_OFFENSES,
    ('FELONY', 'DANGEROUS DRUGS'):                              FELONY_DANGEROUS_DRUGS,
    ('FELONY', 'DANGEROUS WEAPONS'):                            FELONY_DANGEROUS_WEAPONS,
    ('FELONY', 'ENDAN WELFARE INCOMP'):                         FELONY_OTHER_FELONIES,
    ('FELONY', 'FELONY ASSAULT'):                               FELONY_FELONY_ASSAULT,
    ('FELONY', 'FORGERY'):                                      FELONY_FORGERY_FRAUD_IDENTITY_THEFT,
    ('FELONY', 'GAMBLING'):                                     FELONY_OTHER_FELONIES,
    ('FELONY', 'GRAND LARCENY'):                                FELONY_GRAND_LARCENY,
    ('FELONY', 'GRAND LARCENY OF MOTOR VEHICLE'):               FELONY_GRAND_LARCENY_OF_MOTOR_VEHICLE,
    ('FELONY', 'HOMICIDE-NEGLIGENT,UNCLASSIFIE'):               FELONY_MURDER_AND_NON_NEGL_MANSLAUGHTER,
    ('FELONY', 'HOMICIDE-NEGLIGENT-VEHICLE'):                   FELONY_MURDER_AND_NON_NEGL_MANSLAUGHTER,
    ('FELONY', 'INTOXICATED/IMPAIRED DRIVING'):                 FELONY_OTHER_FELONIES,
    ('FELONY', 'KIDNAPPING'):                                   FELONY_OTHER_FELONIES,
    ('FELONY', 'KIDNAPPING & RELATED OFFENSES'):                FELONY_OTHER_FELONIES,
    ('FELONY', 'MISCELLANEOUS PENAL LAW'):                      FELONY_OTHER_FELONIES,
    ('FELONY', 'MURDER & NON-NEGL. MANSLAUGHTER'):              FELONY_MURDER_AND_NON_NEGL_MANSLAUGHTER,
    ('FELONY', 'NYS LAWS-UNCLASSIFIED FELONY'):                 FELONY_OTHER_FELONIES,
    ('FELONY', 'POSSESSION OF STOLEN PROPERTY'):                FELONY_POSSESSION_OF_STOLEN_PROPERTY,
    ('FELONY', 'PROSTITUTION & RELATED OFFENSES'):              FELONY_SEX_CRIMES,
    ('FELONY', 'ROBBERY'):                                      FELONY_ROBBERY,
    ('FELONY', 'SEX CRIMES'):                                   FELONY_SEX_CRIMES,
    ('FELONY', 'THEFT-FRAUD'):                                  FELONY_FORGERY_FRAUD_IDENTITY_THEFT,

    ('MISDEMEANOR', 'ADMINISTRATIVE CODE'):                     MISDEMEANOR_ADMINISTRATIVE_CODE,
    ('MISDEMEANOR', 'AGRICULTURE & MRKTS LAW-UNCLASSIFIED'):    MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'ALCOHOLIC BEVERAGE CONTROL LAW'):          MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'ANTICIPATORY OFFENSES'):                   MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'ASSAULT 3 & RELATED OFFENSES'):            MISDEMEANOR_ASSAULT_3_AND_RELATED_OFFENSES,
    ('MISDEMEANOR', "BURGLAR'S TOOLS"):                         MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'CRIMINAL MISCHIEF & RELATED OF'):          MISDEMEANOR_CRIMINAL_MISCHIEF_AND_RELATED_OFFENSES,
    ('MISDEMEANOR', 'CRIMINAL TRESPASS'):                       MISDEMEANOR_CRIMINAL_TRESPASS,
    ('MISDEMEANOR', 'DANGEROUS DRUGS'):                         MISDEMEANOR_DANGEROUS_DRUGS,
    ('MISDEMEANOR', 'DANGEROUS WEAPONS'):                       MISDEMEANOR_DANGEROUS_WEAPONS,
    ('MISDEMEANOR', 'DISRUPTION OF A RELIGIOUS SERV'):          MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'ENDAN WELFARE INCOMP'):                    MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'ESCAPE 3'):                                MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'FRAUDS'):                                  MISDEMEANOR_FRAUDS,
    ('MISDEMEANOR', 'FRAUDULENT ACCOSTING'):                    MISDEMEANOR_FRAUDS,
    ('MISDEMEANOR', 'GAMBLING'):                                MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'INTOXICATED & IMPAIRED DRIVING'):          MISDEMEANOR_INTOXICATED_AND_IMPAIRED_DRIVING,
    ('MISDEMEANOR', 'JOSTLING'):                                MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'NEW YORK CITY HEALTH CODE'):               MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'OFF. AGNST PUB ORD SENSBLTY &'):           MISDEMEANOR_OFFENSES_AGAINST_PUBLIC_ADMINISTRATION,
    ('MISDEMEANOR', 'OFFENSES AGAINST PUBLIC ADMINI'):          MISDEMEANOR_OFFENSES_AGAINST_PUBLIC_ADMINISTRATION,
    ('MISDEMEANOR', 'OFFENSES AGAINST PUBLIC SAFETY'):          MISDEMEANOR_OFFENSES_AGAINST_PUBLIC_ADMINISTRATION,
    ('MISDEMEANOR', 'OFFENSES AGAINST THE PERSON'):             MISDEMEANOR_OFFENSES_AGAINST_THE_PERSON,
    ('MISDEMEANOR', 'OFFENSES INVOLVING FRAUD'):                MISDEMEANOR_FRAUDS,
    ('MISDEMEANOR', 'OFFENSES RELATED TO CHILDREN'):            MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'OTHER OFFENSES RELATED TO THEF'):          MISDEMEANOR_PETIT_LARCENY,
    ('MISDEMEANOR', 'OTHER STATE LAWS (NON PENAL LAW)'):        MISDEMEANOR_OTHER_MISDEMEANORS,
    ('MISDEMEANOR', 'PETIT LARCENY'):                           MISDEMEANOR_PETIT_LARCENY,
    ('MISDEMEANOR', 'PETIT LARCENY OF MOTOR VEHICLE'):          MISDEMEANOR_PETIT_LARCENY,
    ('MISDEMEANOR', 'POSSESSION OF STOLEN PROPERTY'):           MISDEMEANOR_POSSESSION_OF_STOLEN_PROPERTY,
    ('MISDEMEANOR', 'PROSTITUTION & RELATED OFFENSES'):         MISDEMEANOR_SEX_CRIMES,
    ('MISDEMEANOR', 'SEX CRIMES'):                              MISDEMEANOR_SEX_CRIMES,
    ('MISDEMEANOR', 'THEFT OF SERVICES'):                       MISDEMEANOR_PETIT_LARCENY,
    ('MISDEMEANOR', 'UNAUTHORIZED USE OF A VEHICLE'):           MISDEMEANOR_UNAUTHORIZED_USE_OF_A_VEHICLE,
    ('MISDEMEANOR', 'VEHICLE AND TRAFFIC LAWS'):                MISDEMEANOR_VEHICLE_AND_TRAFFIC_LAWS,

    ('VIOLATION', 'ADMINISTRATIVE CODE'):                       VIOLATION_OTHER_VIOLATIONS,
    ('VIOLATION', 'DISORDERLY CONDUCT'):                        VIOLATION_OTHER_VIOLATIONS,
    ('VIOLATION', 'HARRASSMENT 2'):                             VIOLATION_HARASSMENT_2,
    ('VIOLATION', 'LOITERING'):                                 VIOLATION_OTHER_VIOLATIONS,
    ('VIOLATION', 'LOITERING/GAMBLING (CARDS, DIC'):            VIOLATION_OTHER_VIOLATIONS,
    ('VIOLATION', 'MISCELLANEOUS PENAL LAW'):                   VIOLATION_OTHER_VIOLATIONS,
    ('VIOLATION', 'NEW YORK CITY HEALTH CODE'):                 VIOLATION_OTHER_VIOLATIONS,
    ('VIOLATION', 'NYS LAWS-UNCLASSIFIED VIOLATION'):           VIOLATION_OTHER_VIOLATIONS,
    ('VIOLATION', 'OTHER STATE LAWS'):                          VIOLATION_OTHER_VIOLATIONS,
    ('VIOLATION', 'UNLAWFUL POSS. WEAP. ON SCHOOL'):            VIOLATION_OTHER_VIOLATIONS,
}
