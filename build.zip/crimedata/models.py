from django.contrib.gis.db import models


class CrimeDataRouter(object):
    def db_for_read(self, model, **hints):
        if model._meta.app_label == 'crimedata':
            return 'crime-data'
        return None

    def db_for_write(self, *args, **kwargs):
        return None

    def allow_relation(self, *args, **kwargs):
        return None

    def allow_migrate(self, *args, **kwargs):
        return None


class CrimeType(models.Model):
    crime = models.CharField(max_length=128)
    type = models.CharField(max_length=128)

    class Meta:
        managed = False
        db_table = 'crime_types'


class PolicePrecinct(models.Model):
    precinct = models.IntegerField()
    geometry = models.MultiPolygonField(db_column='geom')

    class Meta:
        db_table = 'police_precincts'


class PrecinctCrime(models.Model):
    id = models.BigAutoField(primary_key=True)

    precinct = models.IntegerField()
    crime = models.CharField(max_length=128, blank=True, null=True)
    crime_type = models.ForeignKey(CrimeType, on_delete=models.SET_NULL, null=True)

    year_2000 = models.IntegerField(db_column='2000')
    year_2001 = models.IntegerField(db_column='2001')
    year_2002 = models.IntegerField(db_column='2002')
    year_2003 = models.IntegerField(db_column='2003')
    year_2004 = models.IntegerField(db_column='2004')
    year_2005 = models.IntegerField(db_column='2005')
    year_2006 = models.IntegerField(db_column='2006')
    year_2007 = models.IntegerField(db_column='2007')
    year_2008 = models.IntegerField(db_column='2008')
    year_2009 = models.IntegerField(db_column='2009')
    year_2010 = models.IntegerField(db_column='2010')
    year_2011 = models.IntegerField(db_column='2011')
    year_2012 = models.IntegerField(db_column='2012')
    year_2013 = models.IntegerField(db_column='2013')
    year_2014 = models.IntegerField(db_column='2014')
    year_2015 = models.IntegerField(db_column='2015')
    year_2016 = models.IntegerField(db_column='2016')

    class Meta:
        db_table = 'precinct_historical'


class PoliceLog(models.Model):
    complaint_num = models.IntegerField(primary_key=True)
    report_date = models.DateField(blank=True, null=True)
    crime_type = models.ForeignKey(CrimeType, on_delete=models.SET_NULL, null=True)
    law_category = models.CharField(max_length=50, blank=True, null=True)
    offense = models.CharField(max_length=100, blank=True, null=True)
    geom = models.PointField(blank=True, null=True)

    class Meta:
        db_table = 'police_log'
