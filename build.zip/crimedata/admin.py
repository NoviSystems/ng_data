from django.contrib import admin

from crimedata import models


admin.register(models.CrimeType)
admin.register(models.PolicePrecinct)
admin.register(models.PrecinctCrime)
