from django.conf.urls import url

from . import views


urlpatterns = [
    # A view named "home" is referenced in a few places.
    # Make sure to update the references if you change or delete this url line!
    url(r'^$', views.Home.as_view(), name='home'),
    url(r'^api/precinct-geometries.json', views.precinct_geometries, name='precinct-geometries'),
    url(r'^api/crime-statistics.json', views.crime_statistics, name='crime-statistics'),
    url(r'^api/police-log.json', views.police_log, name='police-log'),
    url(r'^api/kmeans-clusters.json', views.kmeans_clusters, name='kmeans-clusters'),
]
